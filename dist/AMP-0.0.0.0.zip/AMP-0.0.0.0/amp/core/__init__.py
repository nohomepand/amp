# encoding: utf-8
'''
Created on 2020/03/27

@author: oreyou
'''
from __future__ import absolute_import, unicode_literals, print_function

import collections
import functools
import inspect
import sys


OrdDict = collections.OrderedDict # synonym

