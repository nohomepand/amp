# encoding: utf-8
'''
Created on 2020/03/27

@author: oreyou

* application-module-packaging;AMP manager
'''
from __future__ import absolute_import, unicode_literals, print_function
